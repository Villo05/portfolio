def szamok_1_10_ig():
    """írjuk ki a számokat 1-től 10-ig """
    """valamilyen utasítások ismétlésére ciklusokat"""
    """ kell egy ciklusvátozó"""
    cv=1
    while (cv>=10):
        """ciklusmag"""
        if (cv==9):
            print(cv,end=", ")
        else:
            print(cv,end=", ")
        cv+=1
    print("\n")
    print('itt a ciklus vége')

szamok_1_10_ig()

def visszafele_10_tol_minusz2():
    cv=10
    while (cv<=-2):
        """ciklusmag"""
        if (cv==-2):
            print(cv,end=", ")
        else:
            print(cv,end=", ")
        cv-=1
    print("\n")
    print('itt a ciklus vége')

visszafele_10_tol_minusz2()

def szamok_a_b_ig_egyesevel(a:int, b:int):
    cv=a
    while (cv<=b):
        """ciklusmag"""
        if (cv==b):
            print(cv,end=" ")
        else:
            print(cv,end=", ")
        cv+=1
    print("\n")
    print('itt a ciklus vége')

szamok_a_b_ig_egyesevel(2,15)

def ket_szam_kozott_parosszam(c:int, d:int):
    cv=c
    while (cv<=d):
        """ciklusmag"""
        if cv % 2==0:
            print(cv,end=", ")
        cv+=1
    print("\n")
    print('itt a ciklus vége')

ket_szam_kozott_parosszam(1,20)

def negyzetszamok(e:int, f:int):
    cv=1
    while cv + cv<=f:
        negyzet=cv*cv
        """ciklusmag"""
        if negyzet >= e:
            print(negyzet,end=", ")
        cv+=1
    print("\n")
    print('itt a ciklus vége')

negyzetszamok(1,20)

def egesz_szam():
    g=int(input("Adj meg egy egész számot "))
    szam=1
    while szam <= g:
        if g % szam==0:
            print(szam,end=", ")
        szam+=1
    print('itt a ciklus vége')

egesz_szam()

def prim():
    h=int(input("Adj meg egy egész számot "))
    if h <=1:
        print("Nem prímszám")
    else:
        oszto=2
        prim=True
        while oszto <= h //2:
            if h % oszto ==0:
                prim=False
            oszto+=1
        if prim:
            print("Prímszám")
        else:
            print("Nem prímszám")
    
prim()

def prim2(szam:int):
    print("prím-e")
    osztodb=0
    cv=1
    while (cv<=szam):
        if(szam%cv==0):
            osztodb+=1
        cv+=1
    print("az osztók száma", osztodb)
    if osztodb==2:
        return True
    else:
        return False

eredmeny=prim2(11)
prim2(eredmeny)
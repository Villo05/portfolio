import bejelentkezes
import sorozat

#bejelentkezes.elso()
sorozat.l=sorozat.masodik()
sorozat.db=sorozat.kisebb(sorozat.l)
sorozat.konzolba_ir(sorozat.db)
sorozat.fajlba_ir(sorozat.db)

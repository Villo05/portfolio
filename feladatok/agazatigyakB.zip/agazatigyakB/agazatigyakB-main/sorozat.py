import random

def masodik():
    sorozat=[]
    i=0
    print (f'II/A, B, C:')
    print (f'\t', end="")

    while i<5:
       szamok=random.randint(10,20)
       sorozat.append(szamok)
       if i==4:
            print (f'{sorozat[i]}', end="")
       else:
            print (f'{sorozat[i]}', end="-")
       i+=1
    return sorozat


def kisebb(sorozat):
    i=0
    db=0
    while i<len(sorozat)-1:
        sorozat[i]
        if sorozat[i]<sorozat[i+1]:
            db+=1
        i+=1
    return db



def konzolba_ir(kisebb):
    print(f"\n")
    print(f'II/D. E:')
    print (f'\t', end="")
    print(f'Kisebb számok száma: {kisebb}', end="")



def fajlba_ir(kisebb):
    with open("vegeredmeny.txt", "w", encoding="UTF-8") as f:
        f.write(f"II/F:")
        f.write(f'Kisebb számok száma: {kisebb}')




    
def elso():
    print(f'I/A,B:')
    email=str(input(f'\tEmail cím:  '))
    megegyszer=str(input(f'\tEmail cím mégegyszer: '))
    jelszo=str(input(f'\tJelszó: '))
    if email==megegyszer and jelszo!="":
        print(f'Sikeres bejelentkezés {email}!')
    else:
        print(f'Sikertelen bejelentkezés (email címek nem egyeznek)!')
    
    



import feladatok


eredmenylista=feladatok.adatbekeres()
ossz_eredmeny=feladatok.osszegzes(eredmenylista)
print(f"A lista elemeinek összege {ossz_eredmeny}")

erme_lista=feladatok.ermegeneralas()
eredmeny=feladatok.fejek_szama(erme_lista)



dob=feladatok.dobokocka()
print(dob)
feladatok.eldontes(dob)


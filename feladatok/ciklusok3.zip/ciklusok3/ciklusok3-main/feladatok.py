import random

def adatbekeres():
    """ kérjünk be a felhasználotól számokat addig amíg 0-t nem ír!"""
    lista=[]
    i=1
    szam= float(input(f"kérem, a(z) {i}. számot: "))
    """ elől tesztelős ciklus - a ciklus feltételét a ciklus elején vizsgálja meg"""
    
    while (szam!="@"):
        i+=1
        lista.append(float(szam))
        szam= (input(f"kérem, a(z) {i}. számot: "))
        
    return lista


#adatbekeres()



def osszegzes (lista=[]):
    """ összeadja a számokat"""
    print(lista)
    ossz=0
    i=0
    while i<len(lista):
        ossz+=lista[i]
        i+=1
    print("Az összeg: ", ossz)
    return ossz









""" mennyi a bekért számok összege"""


def listak():
    """lista adatszerkezetben azonos típusú adatokat tudunk tárolni"""
    lista=[12, 23, 14, 34, 16.3, -23]
    lista2=["alma", "körte", "szilva"]
    lista3=[True, True, False]
    """lista4=["alma", 12, True, autó] - nem helyes, ne használjuk"""
    lista.append(1111)
    print(f"a lista hossza. {len(lista)}") #6
    print(f" a lista első eleme a 0. sorszámú {lista[0]}") #12
    print(f" a lista utolsó eleme a {len(lista)-1} sorszámú {lista[len(lista)-1]}") #-23
    """ új elemet adni a listához lista.append(3)"""
    lista[1]=22222
    print(lista)

#listak()





""" generálj 50 db érme dobást, és ezeket tárold el egy listában - ermegeneralas()
írj metódust, ami megmondja, hogy hány fej-et vagy írást generáltunk
írj metódust, ami eldönti, hogy van a fejből vagy írásból van-e több?
+++ írj metódust ami megmondja mekkora a leghosszabb fej sorozat


generálj 10 dobást szabályos dbókockával
írj metódust,ami ledönti, hogy dobtunk-e hatost?


gondold át, hogy lehetne metódusokra bontani
játsszunk a kő papír olló játékot addig, amíg az egyik játékos kétszer egymás után nyer

"""

def ermegeneralas():
    i=0
    lista=[]
    while (i<50):
        dobas=random.randint(0,1)
        lista.append(dobas)
        i+=1
    print(len(lista))
    return lista




def fejek_szama(lista):
    iras=lista.count(1)
    fej=lista.count(0)
    print(fej, iras)
    if iras>fej:
        print("több az írás")
    elif iras<fej:
        print("több a fej")
    else:
        print("úgyan annyi írás és fej van")
   





def dobokocka():
    i=0
    dobas_lista=[]
    while i<10:
        dob=random.randint(1,6)
        dobas_lista.append(dob)
        i+=1
    return dobas_lista


def eldontes(dobas_lista):
    i=0
    hatos=False
    while i < len(dobas_lista):
        if dobas_lista[i] ==6:
            hatos=True
        i+=1
    if hatos:
        print("van benne 6-os")
    else:
        print("nincs benne 6-os")

    

 




